#!/usr/bin/env python

import rospy    # Esto es para podernos comunicar con ROS mediante python
import serial   # Necesaria para leer por serial
import time
from std_msgs.msg import Float32  # Voy a publicar en un topico el tipo de dato Float32
from std_msgs.msg import Float32MultiArray  # Voy a publicar en un topico el tipo de dato Float32

flex_array = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
pots_array = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
RPY = [0.0,0.0,0.0]     # Arreglo donde se leen Roll, Pitch & Yaw

# CAMBIAR PUERTO dependiendo del disponible
Arduino = serial.Serial("/dev/Arduino-UNO",115200)       # Crea el puerto serial a cierta velocidad baudrate             

print "Initializing Sensores_node"

def talker():
	# Para ignorar la basura inicial del serial:
	for i in range(1,12):
		data = Arduino.readline()

  	while not rospy.is_shutdown():      # Este es el que nos va a devolver si todo esta bien, es como el while ros ok en C++
		data = Arduino.readline()      # Guardamos en una variable, regla de 3 para que de una vuelta completa
      	
		DataSensors = data.split("#")
		DataFlex = DataSensors[0]
		DataPots = DataSensors[1]
		DataYaw = DataSensors[2]

		FlexSensors = DataFlex.split(",")
		PotsSensors = DataPots.split(",")

		flex_array[0] = float(FlexSensors[0])
		flex_array[1] = float(FlexSensors[1])
		flex_array[2] = float(FlexSensors[2])
		flex_array[3] = float(FlexSensors[3])
		flex_array[4] = float(FlexSensors[4])
		flex_array[5] = float(FlexSensors[5])
		flex_array[6] = float(FlexSensors[6])
		flex_array[7] = float(FlexSensors[7])
		flex_array[8] = float(FlexSensors[8])
		flex_array[9] = float(FlexSensors[9])
		flex_array[10] = float(FlexSensors[10])
	        flex_array[11] = float(FlexSensors[11])
		flex_array[12] = float(FlexSensors[12])
		flex_array[13] = float(FlexSensors[13])
		flex_array[14] = float(FlexSensors[14])
		flex_array[15] = float(FlexSensors[15])

		pots_array[0] = float(PotsSensors[0])
		pots_array[1] = float(PotsSensors[1])
		pots_array[2] = float(PotsSensors[2])
		pots_array[3] = float(PotsSensors[3])
		pots_array[4] = float(PotsSensors[4])
		pots_array[5] = float(PotsSensors[5])
		pots_array[6] = float(PotsSensors[6])
		pots_array[7] = float(PotsSensors[7])
		pots_array[8] = float(PotsSensors[8])
		pots_array[9] = float(PotsSensors[9])
		pots_array[10] = float(PotsSensors[10])
		pots_array[11] = float(PotsSensors[11])
		pots_array[12] = float(PotsSensors[12])
		pots_array[13] = float(PotsSensors[13])
		pots_array[14] = float(PotsSensors[14])
		pots_array[15] = float(PotsSensors[15])

		flex_data.data = flex_array
		pots_data.data = pots_array

		#print " DataFlex: " + DataFlex + " DataPots: " + DataPots + " Yaw: " + DataYaw

		#rospy.loginfo(data)             # Para mostrar lo que le esta llegando
		pubFlex.publish(flex_data)        # Conversion a flotante
		pubPots.publish(pots_data)
		pubYaw.publish(float(DataYaw))

	rospy.sleep(0.0001)              # Lo que duerme

if __name__ == '__main__':
  try:
    # Publicador
    pubFlex = rospy.Publisher("/flex",Float32MultiArray,queue_size=1);
    pubPots = rospy.Publisher("/pots",Float32MultiArray,queue_size=1);
    pubYaw = rospy.Publisher("/yaw",Float32,queue_size=1);

    flex_data = Float32MultiArray();
    pots_data = Float32MultiArray();

    rospy.init_node("Sensores_node");   # Inicializa el nodo, es con el que ROS va a identificar el nodo, puede ser distinto el nombre al del nodo, o igual. El punto y coma no es necesario.
    talker()
  except rospy.ROSInterruptException:
    pass
